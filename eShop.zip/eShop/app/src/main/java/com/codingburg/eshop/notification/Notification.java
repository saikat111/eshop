package com.codingburg.eshop.notification;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.codingburg.eshop.R;

public class Notification extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
    }
}